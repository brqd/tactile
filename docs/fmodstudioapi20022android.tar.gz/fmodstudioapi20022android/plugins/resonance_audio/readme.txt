# Resonance Audio SDK for [FMOD](http://www.fmod.com) v1.0

Enables high-quality spatial audio on mobile and desktop platforms.

To get started read the online [documentation](https://resonance-audio.github.io/resonance-audio/develop/fmod/getting-started).

Copyright (c) 2019 Google Inc. All rights reserved.